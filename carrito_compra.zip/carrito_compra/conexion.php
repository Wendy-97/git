<?php 
	$con = mysqli_connect('localhost','root','','carrito') or die('Error: '.mysqli_error($con));
			 
	//Se termina el proceso
			 
?>